
"use strict";

let MoraiScenarioLoadSrv = require('./MoraiScenarioLoadSrv.js')
let MoraiSyncModeCtrlCmdSrv = require('./MoraiSyncModeCtrlCmdSrv.js')
let MoraiSyncModeRemoveObjectSrv = require('./MoraiSyncModeRemoveObjectSrv.js')
let MoraiSyncModeAddObjectSrv = require('./MoraiSyncModeAddObjectSrv.js')
let MoraiTLInfoSrv = require('./MoraiTLInfoSrv.js')
let MoraiVehicleSpecSrv = require('./MoraiVehicleSpecSrv.js')
let MoraiSyncModeCmdSrv = require('./MoraiSyncModeCmdSrv.js')
let FaultInjectionSensorSrv = require('./FaultInjectionSensorSrv.js')
let MoraiMapSpecSrv = require('./MoraiMapSpecSrv.js')
let MoraiSimProcSrv = require('./MoraiSimProcSrv.js')
let MoraiEventCmdSrv = require('./MoraiEventCmdSrv.js')
let MultiPlayEventSrv = require('./MultiPlayEventSrv.js')
let MoraiWaitForTickSrv = require('./MoraiWaitForTickSrv.js')
let FaultInjectionTireSrv = require('./FaultInjectionTireSrv.js')
let WoowaDillyEventCmdSrv = require('./WoowaDillyEventCmdSrv.js')
let MoraiSyncModeSetGearSrv = require('./MoraiSyncModeSetGearSrv.js')
let PREventSrv = require('./PREventSrv.js')
let FaultInjectionCtrlSrv = require('./FaultInjectionCtrlSrv.js')
let MoraiSyncModeSLSrv = require('./MoraiSyncModeSLSrv.js')

module.exports = {
  MoraiScenarioLoadSrv: MoraiScenarioLoadSrv,
  MoraiSyncModeCtrlCmdSrv: MoraiSyncModeCtrlCmdSrv,
  MoraiSyncModeRemoveObjectSrv: MoraiSyncModeRemoveObjectSrv,
  MoraiSyncModeAddObjectSrv: MoraiSyncModeAddObjectSrv,
  MoraiTLInfoSrv: MoraiTLInfoSrv,
  MoraiVehicleSpecSrv: MoraiVehicleSpecSrv,
  MoraiSyncModeCmdSrv: MoraiSyncModeCmdSrv,
  FaultInjectionSensorSrv: FaultInjectionSensorSrv,
  MoraiMapSpecSrv: MoraiMapSpecSrv,
  MoraiSimProcSrv: MoraiSimProcSrv,
  MoraiEventCmdSrv: MoraiEventCmdSrv,
  MultiPlayEventSrv: MultiPlayEventSrv,
  MoraiWaitForTickSrv: MoraiWaitForTickSrv,
  FaultInjectionTireSrv: FaultInjectionTireSrv,
  WoowaDillyEventCmdSrv: WoowaDillyEventCmdSrv,
  MoraiSyncModeSetGearSrv: MoraiSyncModeSetGearSrv,
  PREventSrv: PREventSrv,
  FaultInjectionCtrlSrv: FaultInjectionCtrlSrv,
  MoraiSyncModeSLSrv: MoraiSyncModeSLSrv,
};
