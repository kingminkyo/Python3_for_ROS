
"use strict";

let SetTrafficLight = require('./SetTrafficLight.js');
let FaultInjection_Tire = require('./FaultInjection_Tire.js');
let Lamps = require('./Lamps.js');
let CollisionData = require('./CollisionData.js');
let CtrlCmd = require('./CtrlCmd.js');
let SVADC = require('./SVADC.js');
let ObjectStatusExtended = require('./ObjectStatusExtended.js');
let WoowaDillyStatus = require('./WoowaDillyStatus.js');
let RadarDetection = require('./RadarDetection.js');
let PRCtrlCmd = require('./PRCtrlCmd.js');
let GhostMessage = require('./GhostMessage.js');
let SyncModeResultResponse = require('./SyncModeResultResponse.js');
let FaultInjection_Controller = require('./FaultInjection_Controller.js');
let MapSpecIndex = require('./MapSpecIndex.js');
let MultiPlayEventRequest = require('./MultiPlayEventRequest.js');
let VehicleCollision = require('./VehicleCollision.js');
let SyncModeRemoveObject = require('./SyncModeRemoveObject.js');
let ReplayInfo = require('./ReplayInfo.js');
let PRStatus = require('./PRStatus.js');
let FaultInjection_Response = require('./FaultInjection_Response.js');
let SkidSteer6wUGVStatus = require('./SkidSteer6wUGVStatus.js');
let EgoVehicleStatusExtended = require('./EgoVehicleStatusExtended.js');
let EventInfo = require('./EventInfo.js');
let VehicleSpec = require('./VehicleSpec.js');
let SkateboardCtrlCmd = require('./SkateboardCtrlCmd.js');
let ScenarioLoad = require('./ScenarioLoad.js');
let SyncModeInfo = require('./SyncModeInfo.js');
let MoraiSimProcStatus = require('./MoraiSimProcStatus.js');
let NpcGhostInfo = require('./NpcGhostInfo.js');
let IntersectionControl = require('./IntersectionControl.js');
let SyncModeScenarioLoad = require('./SyncModeScenarioLoad.js');
let SyncModeCtrlCmd = require('./SyncModeCtrlCmd.js');
let MoraiTLInfo = require('./MoraiTLInfo.js');
let ObjectStatusList = require('./ObjectStatusList.js');
let EgoDdVehicleStatus = require('./EgoDdVehicleStatus.js');
let IntscnTL = require('./IntscnTL.js');
let SyncModeSetGear = require('./SyncModeSetGear.js');
let ObjectStatus = require('./ObjectStatus.js');
let MoraiSrvResponse = require('./MoraiSrvResponse.js');
let ObjectStatusListExtended = require('./ObjectStatusListExtended.js');
let VehicleSpecIndex = require('./VehicleSpecIndex.js');
let WaitForTickResponse = require('./WaitForTickResponse.js');
let FaultStatusInfo_Vehicle = require('./FaultStatusInfo_Vehicle.js');
let SyncModeAddObject = require('./SyncModeAddObject.js');
let FaultInjection_Sensor = require('./FaultInjection_Sensor.js');
let SkateboardStatus = require('./SkateboardStatus.js');
let MapSpec = require('./MapSpec.js');
let NpcGhostCmd = require('./NpcGhostCmd.js');
let DillyCmd = require('./DillyCmd.js');
let MoraiTLIndex = require('./MoraiTLIndex.js');
let WaitForTick = require('./WaitForTick.js');
let FaultStatusInfo_Sensor = require('./FaultStatusInfo_Sensor.js');
let ERP42Info = require('./ERP42Info.js');
let EgoVehicleStatus = require('./EgoVehicleStatus.js');
let GetTrafficLightStatus = require('./GetTrafficLightStatus.js');
let SkidSteer6wUGVCtrlCmd = require('./SkidSteer6wUGVCtrlCmd.js');
let MultiPlayEventResponse = require('./MultiPlayEventResponse.js');
let MoraiSimProcHandle = require('./MoraiSimProcHandle.js');
let DdCtrlCmd = require('./DdCtrlCmd.js');
let SaveSensorData = require('./SaveSensorData.js');
let SyncModeCmd = require('./SyncModeCmd.js');
let MultiEgoSetting = require('./MultiEgoSetting.js');
let PREvent = require('./PREvent.js');
let TrafficLight = require('./TrafficLight.js');
let GPSMessage = require('./GPSMessage.js');
let SensorPosControl = require('./SensorPosControl.js');
let FaultStatusInfo_Overall = require('./FaultStatusInfo_Overall.js');
let IntersectionStatus = require('./IntersectionStatus.js');
let RadarDetections = require('./RadarDetections.js');
let FaultStatusInfo = require('./FaultStatusInfo.js');
let VehicleCollisionData = require('./VehicleCollisionData.js');
let DillyCmdResponse = require('./DillyCmdResponse.js');
let SyncModeCmdResponse = require('./SyncModeCmdResponse.js');

module.exports = {
  SetTrafficLight: SetTrafficLight,
  FaultInjection_Tire: FaultInjection_Tire,
  Lamps: Lamps,
  CollisionData: CollisionData,
  CtrlCmd: CtrlCmd,
  SVADC: SVADC,
  ObjectStatusExtended: ObjectStatusExtended,
  WoowaDillyStatus: WoowaDillyStatus,
  RadarDetection: RadarDetection,
  PRCtrlCmd: PRCtrlCmd,
  GhostMessage: GhostMessage,
  SyncModeResultResponse: SyncModeResultResponse,
  FaultInjection_Controller: FaultInjection_Controller,
  MapSpecIndex: MapSpecIndex,
  MultiPlayEventRequest: MultiPlayEventRequest,
  VehicleCollision: VehicleCollision,
  SyncModeRemoveObject: SyncModeRemoveObject,
  ReplayInfo: ReplayInfo,
  PRStatus: PRStatus,
  FaultInjection_Response: FaultInjection_Response,
  SkidSteer6wUGVStatus: SkidSteer6wUGVStatus,
  EgoVehicleStatusExtended: EgoVehicleStatusExtended,
  EventInfo: EventInfo,
  VehicleSpec: VehicleSpec,
  SkateboardCtrlCmd: SkateboardCtrlCmd,
  ScenarioLoad: ScenarioLoad,
  SyncModeInfo: SyncModeInfo,
  MoraiSimProcStatus: MoraiSimProcStatus,
  NpcGhostInfo: NpcGhostInfo,
  IntersectionControl: IntersectionControl,
  SyncModeScenarioLoad: SyncModeScenarioLoad,
  SyncModeCtrlCmd: SyncModeCtrlCmd,
  MoraiTLInfo: MoraiTLInfo,
  ObjectStatusList: ObjectStatusList,
  EgoDdVehicleStatus: EgoDdVehicleStatus,
  IntscnTL: IntscnTL,
  SyncModeSetGear: SyncModeSetGear,
  ObjectStatus: ObjectStatus,
  MoraiSrvResponse: MoraiSrvResponse,
  ObjectStatusListExtended: ObjectStatusListExtended,
  VehicleSpecIndex: VehicleSpecIndex,
  WaitForTickResponse: WaitForTickResponse,
  FaultStatusInfo_Vehicle: FaultStatusInfo_Vehicle,
  SyncModeAddObject: SyncModeAddObject,
  FaultInjection_Sensor: FaultInjection_Sensor,
  SkateboardStatus: SkateboardStatus,
  MapSpec: MapSpec,
  NpcGhostCmd: NpcGhostCmd,
  DillyCmd: DillyCmd,
  MoraiTLIndex: MoraiTLIndex,
  WaitForTick: WaitForTick,
  FaultStatusInfo_Sensor: FaultStatusInfo_Sensor,
  ERP42Info: ERP42Info,
  EgoVehicleStatus: EgoVehicleStatus,
  GetTrafficLightStatus: GetTrafficLightStatus,
  SkidSteer6wUGVCtrlCmd: SkidSteer6wUGVCtrlCmd,
  MultiPlayEventResponse: MultiPlayEventResponse,
  MoraiSimProcHandle: MoraiSimProcHandle,
  DdCtrlCmd: DdCtrlCmd,
  SaveSensorData: SaveSensorData,
  SyncModeCmd: SyncModeCmd,
  MultiEgoSetting: MultiEgoSetting,
  PREvent: PREvent,
  TrafficLight: TrafficLight,
  GPSMessage: GPSMessage,
  SensorPosControl: SensorPosControl,
  FaultStatusInfo_Overall: FaultStatusInfo_Overall,
  IntersectionStatus: IntersectionStatus,
  RadarDetections: RadarDetections,
  FaultStatusInfo: FaultStatusInfo,
  VehicleCollisionData: VehicleCollisionData,
  DillyCmdResponse: DillyCmdResponse,
  SyncModeCmdResponse: SyncModeCmdResponse,
};
