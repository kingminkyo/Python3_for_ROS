#!/usr/bin/env python3
#-*- coding: utf-8 -*-

import cv2
import numpy as np
import rospy
from sensor_msgs.msg import CompressedImage, LaserScan
from cv_bridge import CvBridge
from std_msgs.msg import Float64
import time
import os

from math import *


class StopLine_1():
    def __init__(self):
        rospy.Subscriber("/image_jpeg/compressed", CompressedImage, self.image_callback_1)
        self.speed_pub = rospy.Publisher("/commands/motor/speed", Float64, queue_size=1)
        self.steer_pub = rospy.Publisher("/commands/servo/position", Float64, queue_size=1)
        # self.speed_pub = rospy.Publisher("/request/motor/speed", Float64, queue_size=1)
        # self.steer_pub = rospy.Publisher("/request/steer/angle", Float64, queue_size=1)
        self.bridge = CvBridge()
        rospy.Subscriber("/lidar2D", LaserScan, self.lidar_callback)

        self.print_cnt_1 = True
        self.print_cnt_2 = True
        self.print_cnt_3 = True
        self.print_cnt_4 = True
        self.print_cnt_5 = True
        self.print_cnt_6 = True

        #====================정지선 관련=========================
        self.stop_line_apart = 6                    

        self.vertical_line_threshold = 4 #정지선 Houghline 개수 
        self.stop_detected_index_1 = 4
        self.last_time_updated = 0
        self.last_time_updated_2 = 0
        self.stop_line_action = False
        self.stop_line_action_3 = True
        self.stop_line_action_4 = False
        self.is_turning_left = False        

        #====================라이다 관련========================
        self.obstacle_detected = False
        self.obstacle_last_detected_time = 0  # 장애물이 마지막으로 감지된 시간 초기화

        self.obstacle_detection_time = 0
        self.wait_time_after_obstacle = 5  # 장애물 감지 후 대기 시간 (초)

        self.safe_range =   1.8
    
        self.degrees = []
        self.degree_flag = False
        self.obsobs = False 
        self.number = 1 
        self.driving = False
        
        #====================정지선 관련=========================

        #====================정지선2 관련=========================
        self.stop_line_apart = 6                    

        self.vertical_line_threshold_2 = 5 #정지선2 Houghline 개수 
        # self.stop_detected_index_1 = 4
        self.stop_detected_index_2 = 0
        self.last_time_updated = 0
        self.last_time_updated_2 = 0
        self.stop_line_action_2 = False
        self.last_stop_detected = False
        
        self.no_more_stop_line_2 = False
        
        self.is_turning_left = False
        #====================정지선2 관련=========================

    def reset_stop_line_action(self, event):
        self.stop_line_action= False
        rospy.set_param("stop_line_1_mode", False)
    
    def reset_stop_line_action_2(self, event):
        self.stop_line_action_2 = False
        rospy.set_param("stop_line_1_mode", False)

    
    def reset_stop_line_action_3(self, event):
        self.stop_line_action_3 = True
    
    def reset_stop_line_action_4(self, event):
        self.stop_line_action_4 = False
        rospy.set_param("stop_line_1_mode", False)
        
    def reset_last_stop_detected(self, event):
        self.last_stop_detected = False


    def handle_rotary_stop_line(self):
        print("로터리 정지선 감지 후 처리 로직")
        self.speed_pub.publish(0)  # 차량 정지
        obstacle_detected = False
        start_time = rospy.get_time()

        while rospy.get_time() - start_time < 10:  # 10초간의 체크 기간
            if self.obstacle_detected:
                obstacle_detected = True
                print("라이다 감지: 장애물 발견")  # 라이다가 장애물을 감지했을 때 출력

            if obstacle_detected and rospy.get_time() - self.obstacle_last_detected_time > 2:
                # 장애물이 한 번 이상 감지된 후 2초간 감지되지 않았다면 주행 시작
                # 첫 번째 주행 구간: 0.5초간 주행
                self.speed_pub.publish(1500)  # 속도 설정
                self.steer_pub.publish(0.5)  # 조향각 설정
                drive_start_time = rospy.get_time()

                while rospy.get_time() - drive_start_time < 0.3:
                    pass  # 0.5초간 주행

                # 두 번째 주행 구간: 1.5초간 다른 방향으로 주행
                self.speed_pub.publish(1500)  # 다른 속도 설정
                self.steer_pub.publish(0.75)  # 다른 조향각 설정
                drive_start_time = rospy.get_time()  # 주행 시작 시간 재설정

                while rospy.get_time() - drive_start_time < 2:
                    pass  # 1.5초간 주행

                self.speed_pub.publish(0)  # 주행 멈춤
                # rospy.set_param('stop_line', False)  # 정지선 파라미터를 False로 설정
                break
            



    def lidar_callback(self, msg):
    
        e_stop_degree_list = []
        
        if self.degree_flag == False:
            self.degrees = [msg.angle_min * 180 / pi + msg.angle_increment * 180 / pi * index for index, value in enumerate(msg.ranges)]
            self.degree_flag = True

        for index, value in enumerate(msg.ranges):
            if 170 < abs(self.degrees[index]) and 0 < value < self.safe_range:
                e_stop_degree_list.append(self.degrees[index])

        if len(e_stop_degree_list) >= 3:
            self.obstacle_detected = True
            self.obstacle_last_detected_time = rospy.get_time()
        else:
            self.obstacle_detected = False


        
    def image_callback_1(self, _data):
        # traffic_light_mode = rospy.get_param('traffic_light_mode')
        traffic_light_mode = False

        # np_arr = np.frombuffer(mㅈsg.data, np.uint8)
        # image = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        # cv2.imshow('test4',image)
        if traffic_light_mode :
            pass
        else : 
            cv_image = self.bridge.compressed_imgmsg_to_cv2(_data)
        #=========================================================정지선 인덱싱=========================================================            
            p1 = [300, 290]  # 좌상
            p2 = [290, 320] # 좌하
            p3 = [340, 290] # 우상
            p4 = [350, 320]  # 우하
            
            # p1 = [150, 350]  # 좌상
            # p2 = [100, 435] # 좌하
            # p3 = [450, 350] # 우상
            # p4 = [500, 435]  # 우하


            # corners_point_arr는 변환 이전 이미지 좌표 4개 
            corner_points_arr = np.float32([p1, p2, p3, p4])
            height = 480
            width = 640

            image_p1 = [0, 0]
            image_p2 = [0, height]
            image_p3 = [width, 0]
            image_p4 = [width, height]

            image_params_1 = np.float32([image_p1, image_p2, image_p3, image_p4])


            mat_1 = cv2.getPerspectiveTransform(corner_points_arr, image_params_1)
            # mat = 변환행렬(3*3 행렬) 반
            image_transformed_1 = cv2.warpPerspective(cv_image, mat_1, (width, height))
            # cv2.imshow('tes3',image_transformed_1)

            roi_mask = np.zeros_like(cv_image[:, :, 0])
            roi_mask[:, :] = 255
            stop_line_region_1 = cv2.bitwise_and(image_transformed_1, image_transformed_1, mask=roi_mask)
            # cv2.circle(cv_image, p1, 2, (0, 255, 0), -1)
            # cv2.circle(cv_image, p2, 2, (0, 255, 0), -1)
            # cv2.circle(cv_image, p3, 2, (0, 255, 0), -1)
            # cv2.circle(cv_image, p4, 2, (0, 255, 0), -1)
            # cv2.imshow('wunbon',cv_image)

            gray_frame_1 = cv2.cvtColor(stop_line_region_1, cv2.COLOR_BGR2GRAY)
            blur_img_1 = cv2.GaussianBlur(gray_frame_1, (5, 5), 5)
            # threshold1 증가하면 떨어져 있는 직선끼리 서로 잘 연결됨, threshold2 올리면 올릴수록 더 뚜렷한 직선만 검출
            # edges = cv2.Canny(blur_img_1, threshold1=10, threshold2=25) # 어두컴컴 적운형 구름 일요일, 오후 6시
            # edges = cv2.Canny(blur_img_1, threshold1=15, threshold2=50) # 해가 쨍한데 구름에 가려졌을 때
            edges_1 = cv2.Canny(blur_img_1, threshold1=25, threshold2=60) # 중간
            # edges_1 = cv2.Canny(blur_img_1, threshold1=40, threshold2=75) # 해가 구름에 안가려져서 쨍할 때
            # cv2.imshow('edge',edges_1)

            stop_lines_1 = cv2.HoughLinesP(edges_1, rho=1, theta=np.pi/180, threshold=20, minLineLength=140, maxLineGap=20)
            output_image_1 = np.copy(stop_line_region_1)

            vertical_lines_1 = 0

            if stop_lines_1 is not None:
                for line in stop_lines_1:
                    x1, y1, x2, y2 = line[0]

                    slope = (y2 - y1) / (x2 - x1 + 1e-5)  

                    slope_threshold = 0.1 # 9 or 10
                    if slope_threshold >= abs(slope)  :
                        cv2.line(output_image_1, (x1, y1), (x2, y2), (0, 0, 255), 2)
                        vertical_lines_1 += 1 
                        # print(vertical_lines_1)
                    else:
                        pass  
                # if vertical_lines_1 >= self.vertical_line_threshold and self.last_stop_detected == False:  # 3초동안 임계값 넘어도 +1 안됨
                if vertical_lines_1 >= self.vertical_line_threshold and time.time() - self.last_time_updated >= 4 and self.last_stop_detected == False:  # 3초동안 임계값 넘어도 +1 안됨
                    self.stop_detected_index_1 += 1
                    self.last_time_updated = time.time()
                    self.stop_line_action = True
                    # self.stop_line_action_3 = False
                    self.stop_line_action_4 = True

                    # self.last_stop_detected = True
                    print("[현재 차선]정지선 발견")

                    rospy.Timer(rospy.Duration(4), self.reset_last_stop_detected, oneshot=True) # 4초간 모든 정지선 무시
                    rospy.Timer(rospy.Duration(1.5), self.reset_stop_line_action, oneshot=True) #직빨 시간
                    # rospy.Timer(rospy.Duration(1.5), self.reset_stop_line_action_3, oneshot=False) #7번 인덱스 우회전 시간 1.5초 있다가 우회전 시작 # 왜 얘로 7번 인덱스 우회전 잡으면 안되고 action으로 잡으면 될까?
                    # rospy.Timer(rospy.Duration(3.2), self.reset_stop_line_action_4, oneshot=True) #7번 인덱스 우회전 시간 액션 4 - 액션 3 시간동안 우회전
                    # print('Stop !')s

                # cv2.imshow('Detected Stop Lines', output_image_1)
            # if rospy.get_param('stop_line_mode'):
            cv2.imshow('stop_line_1',output_image_1)

            # print("self.stop_detected_index_1 : ", self.stop_detected_index_1)
            # print("self.stop_line_action : ", self.stop_line_action)
            # print("self.stop_line_action_3 : ", self.stop_line_action_3)
            # print("self.stop_line_action_4 : ", self.stop_line_action_4)
        #=========================================================정지선 인덱싱=========================================================            

        #=========================================================정지선2 인덱싱=========================================================
            s1 = [95, 255]  # 좌상
            s2 = [65, 265] # 좌하
            s3 = [225, 255] # 우상
            s4 = [255, 265]  # 우하

            # s1 = [180, 250]  # 좌상
            # s2 = [175, 255] # 좌하
            # s3 = [300, 250] # 우상
            # s4 = [305, 255]  # 우하


            corner_points_arr = np.float32([s1, s2, s3, s4])
            height = 480
            width = 640

            image_s1 = [0, 0]
            image_s2 = [0, height]
            image_s3 = [width, 0]
            image_s4 = [width, height]

            # cv2.imshow("cv_image",cv_image)
            # cv2.circle(cv_image, s1, 2, (0, 255, 0), -1)
            # cv2.circle(cv_image, s2, 2, (0, 255, 0), -1)
            # cv2.circle(cv_image, s3, 2, (0, 255, 0), -1)
            # cv2.circle(cv_image, s4, 2, (0, 255, 0), -1)

            image_params_2 = np.float32([image_s1, image_s2, image_s3, image_s4])
            mat_2 = cv2.getPerspectiveTransform(corner_points_arr, image_params_2)
            # mat_2 = 변환행렬(3*3 행렬) 반
            roi_mask = np.zeros_like(cv_image[:, :, 0])
            roi_mask[:, :] = 255
            image_transformed_2 = cv2.warpPerspective(cv_image, mat_2, (width, height))
            stop_line_region_2 = cv2.bitwise_and(image_transformed_2, image_transformed_2, mask=roi_mask)
            
            gray_frame_2 = cv2.cvtColor(stop_line_region_2, cv2.COLOR_BGR2GRAY)
            blur_img_2 = cv2.GaussianBlur(gray_frame_2, (5, 5), 5)
            edges_2 = cv2.Canny(blur_img_2, threshold1=25, threshold2=55) # 중간

            stop_lines_2 = cv2.HoughLinesP(edges_2, rho=1, theta=np.pi/180, threshold=20, minLineLength=60, maxLineGap=10)
            output_image_2 = np.copy(stop_line_region_2)

            vertical_lines_2 = 0


            # if stop_lines_2 is not None:
            #     for line in stop_lines_2:
            #         x1, y1, x2, y2 = line[0]

            #         slope = (y2 - y1) / (x2 - x1 + 1e-5)  

            #         slope_threshold = 0.1
            #         if slope_threshold >= abs(slope)  :
            #             cv2.line(output_image_2, (x1, y1), (x2, y2), (0, 0, 255), 2)
            #             vertical_lines_2 += 1 
            #             # print(vertical_lines_2)
            #         else:
            #             pass  

            #     # if vertical_lines_2 >= self.vertical_line_threshold_2 :
            #     # if vertical_lines_2 >= self.vertical_line_threshold_2 and not self.no_more_stop_line_2:
            #     if vertical_lines_2 >= self.vertical_line_threshold_2 and time.time() - self.last_time_updated_2 >= 2 and not self.no_more_stop_line_2:
            #         self.stop_detected_index_2 += 1
            #         self.last_time_updated_2 = time.time()
            #         self.stop_line_action_2 = True

            #         print("[건녀편 차선]정지선 발견")

            #         self.last_stop_detected = True

            #         rospy.Timer(rospy.Duration(3), self.reset_last_stop_detected, oneshot=True) # 3초간 모든 정지선 무시
                    
                    
                    
                    # print("self.last_stop_detected : ",self.last_stop_detected) 
                    # rospy.Timer(rospy.Duration(2.4), self.reset_stop_line_action_2, oneshot=True) #index_2 좌회전 시간
            # cv2.imshow('stop_line_2',output_image_2)
            # print("self.stop_line_action_2 : ", self.stop_line_action_2)
            # print("self.stop_detected_index_2 : ", self.stop_detected_index_2)
            # print("================================")   
            # os.system('clear')
                
        #=========================================================정지선2 인덱싱=========================================================  

        #=========================================================정지선1 제어=========================================================
            # if self.stop_detected_index_1 in [1, 2] and self.stop_line_action and self.last_stop_detected == False :
            # # if self.stop_detected_index_1 in [2, 8] and self.stop_line_action : #정적 or 동적
            #     rospy.set_param("stop_line_1_mode", True)
            #     self.speed_pub.publish(3000)
            #     self.steer_pub.publish(0.5)
            #     # pass

            # elif self.stop_detected_index_1 in [3] and self.stop_line_action and self.last_stop_detected == False :
            #     if self.print_cnt_1:
            #         print("[3번째 index] : 주행중")
            #         self.print_cnt_1 = False

            #     pass

            # elif self.stop_detected_index_1 == 4 and self.stop_line_action and self.last_stop_detected == False : # 정적 or 동적
            #     rospy.set_param("stop_line_1_mode", True)
            #     self.speed_pub.publish(2000)
            #     self.steer_pub.publish(0.492)

            #     if self.print_cnt_2:
            #         print("[4번째 index] : 건너편 정지선 인지 구간")
            #         self.print_cnt_2 = False
            #     # pass

            if self.stop_detected_index_1 == 5 and self.stop_line_action and self.last_stop_detected == False :
                # rospy.set_param("stop_line_1_mode", True)
                print("[5번째 index] : 로터리 앞 정지, 핸들링 시작 ")
                self.handle_rotary_stop_line()
                print("핸들링 함수 끝")
                self.speed_pub.publish(0)
                if self.print_cnt_3:
                    self.print_cnt_3 = False
                
            elif self.stop_detected_index_1 == 6 and self.stop_line_action and self.last_stop_detected == False :
                rospy.set_param("stop_line_1_mode", True)
                self.speed_pub.publish(0)
                if self.print_cnt_4:
                    print("[6번째 index] : (교차로? 미리 뺄건지 정해야함) 정지")
                    self.print_cnt_4 = False

            elif self.stop_detected_index_1 == 7 and self.stop_line_action and self.stop_line_action_4 : 
                rospy.set_param("stop_line_1_mode", True)
                self.speed_pub.publish(1000)
                self.steer_pub.publish(0.5)

            elif self.stop_detected_index_1 == 7 and not self.stop_line_action and self.stop_line_action_4 :  # 왜 3은 안되고 1은 될까
            # elif self.stop_detected_index_1 == 1 and self.stop_line_action_3 and self.stop_line_action_4 : 
                rospy.set_param("stop_line_1_mode", True)
                self.speed_pub.publish(1000)
                self.steer_pub.publish(0.95)
                if self.print_cnt_6 :
                    print("[7번째 index] : 1차선 -> 1차선 우회전")
                    self.print_cnt_6 = False

            elif self.stop_detected_index_1 == 8 and self.stop_line_action and self.last_stop_detected == False :
                rospy.set_param("stop_line_1_mode", True)
                self.speed_pub.publish(3000)
                self.steer_pub.publish(0.505)

        #=========================================================정지선1 제어=========================================================

            elif self.stop_detected_index_2 == 2 and self.stop_line_action_2 :
                    rospy.set_param("stop_line_1_mode", True)
                    self.speed_pub.publish(700)
                    self.steer_pub.publish(0.05)
                    # self.speed_pub.publish(0)
                    
                    if self.print_cnt_5 :
                        print("[건너편 정지선 인지] : 좌회전")
                        self.no_more_stop_line_2 = True
                        self.print_cnt_5 = False
                    # pass
            else: 
                pass
                
            # cv2.imshow('Detected Stop Lines', output_image)
            # cv2.imshow('result',output_image)
        cv2.waitKey(1)
    
# 실제 코드 동작 시, 실행할 코드
def run():
    rospy.init_node("stop_line_1_node")     # camera_example이라는 이름으로 노드를 ROS_MASTER에 등록해주는 코드 (이름이 겹치지만 않으면 됨) 
    new_class = StopLine_1()          # 실제 동작을 담당할 Object
    rospy.spin()                         # ROS Node가 종료되지 않고, Callback 함수를 정상적으로 실행해주기 위한 부분 (코드를 유지하면서, 지속적으로 subscriber를 호출해주는 함수)

if __name__ == '__main__':               # 해당 Python 코드를 직접 실행할 때만 동작하도록 하는 부분
    run()                                # 실제 동작하는 코드
