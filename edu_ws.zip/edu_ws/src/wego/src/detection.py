#!/usr/bin/env python3

import rospy

from std_msgs.msg import Float64
from sensor_msgs.msg import LaserScan
#from wego.msg import lanechange  커스텀 메시지 만들어서 lane 정보 받아보기

from math import *
import os
import time

#param 이용해서 차선 정보 받아들일 필요가 있음 +++ lane detection 파일이랑 조합
class Obstruct_detection:
    def __init__(self):
        # rospy.Subscriber("/request/lane", Int32, self.lane_callback)
        self.lane_pub = rospy.Publisher("/lane", Float64, queue_size=10)
        self.obstacle_pub = rospy.Publisher("/obstacle", Float64, queue_size=10)
        self.speed_pub = rospy.Publisher("/commands/motor/speed", Float64, queue_size=10)
        self.steer_pub = rospy.Publisher("/commands/servo/position", Float64, queue_size=10)
        rospy.Subscriber("/lidar2D", LaserScan, self.lidar_callback)


        self.laser_msg = LaserScan()
        self.safe_range =   1.5
    
        self.degrees = []
        self.degree_flag = False
        self.new_degrees= []



        self.t_1 = 0
        self.t_2 = 0
        self.time = 0

        self.detecting = False
    
        self.dynamic = 0
        self.static = 0

    def lidar_callback(self, msg):
        
        if rospy.get_param("stat_obs_detect_mode") == False and rospy.get_param('dynamic_obs_detect_mode') == False:

            self.speed_pub.publish(1600)   # normal driving info 대로 주행하면 될듯...?
            self.steer_pub.publish(0.5)    # 우선 카메라를 잘 모르니 이대로 
            self.obstacle_pub.publish(0)
            
            e_stop_degree_list = []
            new_stop_degree_list = []
            
        
            if self.degree_flag == False :
                self.degrees = [msg.angle_min*180/pi + msg.angle_increment*180/pi * index for index, value in enumerate(msg.ranges)]
                self.degree_flag = True


            for index, value in enumerate(msg.ranges) :
                if 150 < abs(self.degrees[index]) and 0 < value < self.safe_range :   
                    e_stop_degree_list.append(self.degrees[index])
                
            if len(e_stop_degree_list) >= 1 and self.detecting == False :
                self.detecting = True

            if self.detecting == True :
                self.speed_pub.publish(0)
                self.steer_pub.publish(0.5)
                # rospy.loginfo('stop')     
                self.timing(1)    
                self.new_degrees = [msg.angle_min*180/pi + msg.angle_increment*180/pi * index for index, value in enumerate(msg.ranges)]
                for index, value in enumerate(msg.ranges) :
                    if 150 < abs(self.new_degrees[index]) and 0 < value < self.safe_range :   
                        new_stop_degree_list.append(self.degrees[index])
                # rospy.loginfo("hello")
                # rospy.loginfo(new_stop_degree_list)


            if len(new_stop_degree_list) == 0 and self.detecting == True :

                rospy.set_param("dynamic_obs_detect_mode", True)
                self.obstacle_pub.publish(1) # dynamic
                self.detecting = False
            if len(new_stop_degree_list) != 0 and self.detecting == True :
                rospy.loginfo('static')
                rospy.set_param("stat_obs_detect_mode", True)
                self.obstacle_pub.publish(2) # static
                self.detecting = False

            


    def timing(self,count) :     #시간 세어주는 함수
        self.t_1 = rospy.get_time()
        self.t_2 = rospy.get_time()
        self.time = self.t_2 - self.t_1
        while self.time <= count :
            self.t_2 = rospy.get_time()
            self.time = self.t_2- self.t_1
            rospy.loginfo('checking')


        
def main():
    rospy.init_node('lidar_detection')
    obstruct = Obstruct_detection()
    rospy.spin()

if __name__ == "__main__":
    main()