#!/usr/bin/env python3

import rospy

from std_msgs.msg import Float64
from sensor_msgs.msg import LaserScan
#from wego.msg import lanechange  커스텀 메시지 만들어서 lane 정보 받아보기

from math import *
import os
import time

#param 이용해서 차선 정보 받아들일 필요가 있음 +++ lane detection 파일이랑 조합
class Obstruct :
    def __init__(self):
        # rospy.Subscriber("/request/lane", Int32, self.lane_callback)
        self.speed_pub = rospy.Publisher("/commands/motor/speed", Float64, queue_size=10)
        self.steer_pub = rospy.Publisher("/commands/servo/position", Float64, queue_size=10)
        rospy.Subscriber("/lidar2D", LaserScan, self.lidar_callback)

        # self.speed_msg = Float64()
        # self.steer_msg = Float64()


        self.laser_msg = LaserScan()
        self.safe_range =   1.8
    
        self.degrees = []
        self.degree_flag = False
        self.obsobs = False 

        self.current_lane = 1
        self.mid_steer = 0.5
        self.right_steer = 0.6
        self.left_steer = 0.4
       
        ## 차선 변경 ####
        self.changing_lane = False
        self.semi_changing_lane = False
        self.my_lane_number = 2
        self.cnt_1 = 0
        self.cnt_2 = 0
        self.time = 0
        self.print_cnt = True

        self.dynamic = 0
        self.static = 0

    # def lane_callback(self,msg):
        # self.current_lane = msg.data

    def lidar_callback(self, msg):
            print("시작")
            e_stop_degree_list = []
            
        
            if self.degree_flag == False :
                self.degrees = [msg.angle_min*180/pi + msg.angle_increment*180/pi * index for index, value in enumerate(msg.ranges)]
                self.degree_flag = True


            for index, value in enumerate(msg.ranges) :
                if 170 < abs(self.degrees[index]) and 0 < value < self.safe_range :   # 좌우당  10도씩 , 1.5m이내에 장애물이 들어오면 거름
                    e_stop_degree_list.append(self.degrees[index])
                
            if len(e_stop_degree_list) >= 3:
                self.obstacle = 1

            
            if self.obstacle == 1 :
                print("정적 장애물 발견!")
                if self.my_lane_number == 2:
                    self.timing()
                    while self.obstacle == 1 and  self.time < 1 :
                        self.moving_left()
                        self.cnt_2 = rospy.get_time()
                        self.time = self.cnt_2 - self.cnt_1
                        # print("바깥 >>>>>>안쪽")

                    self.timing()
                    while self.time <  1.0 :
                        self.moving_right()
                        self.cnt_2 = rospy.get_time()
                        self.time = self.cnt_2 - self.cnt_1
                    

                self.my_lane_number = 1
                self.obstacle = 0
                self.cnt_1 = 0
                self.cnt_2 = 0
                self.time = 0

            if self.obstacle == 1 :

                print("정적 장애물 발견!")
                if self.my_lane_number == 1:
                    self.timing()
                    while self.obstacle == 1 and  self.time < 1 :
                        self.moving_right()
                        self.cnt_2 = rospy.get_time()
                        self.time = self.cnt_2 - self.cnt_1
                        # print("안쪽 >>>>>>바깥")

                    self.timing()
                    while self.time <  1.0 :
                        self.moving_left()
                        self.cnt_2 = rospy.get_time()
                        self.time = self.cnt_2 - self.cnt_1
                    

                self.my_lane_number = 2
                self.obstacle = 0
                self.cnt_1 = 0
                self.cnt_2 = 0
                self.time = 0

            self.speed_pub.publish(1600)
            self.steer_pub.publish(self.mid_steer)
            


    def timing(self) :     #시간 세어주는 함수
        self.cnt_1 = rospy.get_time()
        self.cnt_2 = rospy.get_time()
        self.time = self.cnt_2 - self.cnt_1

    def moving_left(self) :
        self.speed_pub.publish(1600)
        self.steer_pub.publish(self.left_steer)
    
    def moving_right(self) :
        self.speed_pub.publish(1600)
        self.steer_pub.publish(self.right_steer)




        
def main():
    rospy.init_node('stat_obstacle')
    obstruct = Obstruct()
    rospy.spin()

if __name__ == "__main__":
    main()