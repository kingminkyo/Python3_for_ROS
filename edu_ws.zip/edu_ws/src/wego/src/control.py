#!/usr/bin/env python3

import rospy
from std_msgs.msg import Float64
from sensor_msgs.msg import LaserScan
from math import *
import os
import time

class Control:
    def __init__(self):
        self.speed_pub = rospy.Publisher("/commands/motor/speed", Float64, queue_size=10)
        self.steer_pub = rospy.Publisher("/commands/servo/position", Float64, queue_size=10)
        #rospy.Subscriber("/lane", LaserScan, self.change_callback) 차선 정보를 받아보자... 근데 지금은 처음에 바깥 차선 주행 기준으로 정함
        rospy.Subscriber("/obstacle", Float64, self.obstacle_callback)    
        

        self.mid_steer = 0.5
        self.right_steer = 0.7
        self.left_steer = 0.3
        self.obstacle = 0
        # self.cnt = 0

       

    def obstacle_callback(self, msg):

        if rospy.get_param("stat_obs_detect_mode") == True  or rospy.get_param('dynamic_obs_detect_mode') ==  True:
            self.obstacle = msg.data



            if self.obstacle == 1 :   #dynamic
                self.speed_pub.publish(1000)
                self.steer_pub.publish(self.mid_steer)
                rospy.set_param('dynamic_obs_detect_mode', False)


            if self.obstacle == 2 : # static
                try:
                    lane_info = rospy.get_param("lane_info", default=False)  # default 값 설정
                except KeyError:      
                    lane_info = False

                if  lane_info == False  : # False 값은 바깥차선 기준
                    self.moving_left()
                    self.timing(0.5)
                    self.moving_straight()
                    self.timing(0.5)
                    self.moving_right()
                    self.timing(0.5)
                    self.moving_straight()
                    # self.cnt += 1

                    rospy.set_param("lane_info", True) # True 는 1차선 기준
                    rospy.set_param("stat_obs_detect_mode", False)
                
                else  :
                    self.moving_right()
                    self.timing(0.5)
                    self.moving_straight()
                    self.timing(0.5)
                    self.moving_left()
                    self.timing(0.5)
                    self.moving_straight()
                    # self.cnt += 1
                    rospy.set_param("lane_info", False) # True 는 1차선 기준
                    rospy.set_param("stat_obs_detect_mode", False)
                



    def timing(self, count) :     #시간 세어주는 함수
        self.t_1 = rospy.get_time()
        self.t_2 = rospy.get_time()
        self.time = self.t_2 - self.t_1
        while self.time <= count :
            self.t_2 = rospy.get_time()
            self.time = self.t_2- self.t_1


    def moving_left(self) :
        self.speed_pub.publish(1200)
        self.steer_pub.publish(self.left_steer)

    
    def moving_right(self) :
        self.speed_pub.publish(1200)
        self.steer_pub.publish(self.right_steer)
    
    def moving_straight(self) :
        self.speed_pub.publish(1200)
        self.steer_pub.publish(self.mid_steer)


        
def main():
    rospy.init_node('control')
    control = Control()
    rospy.spin()

if __name__ == "__main__":
    main()
