import rospy
from morai_msgs.msg import GetTrafficLightStatus
from std_msgs.msg import Float64 
import os
import time
from sensor_msgs.msg import CompressedImage
import numpy as np  
import cv2 
import matplotlib.pyplot as plt
from cv_bridge import CvBridge



#SN000005 -- > traffic_light index

class TrafficLight:
    def __init__(self):
        rospy.Subscriber("/GetTrafficLightStatus", GetTrafficLightStatus, callback=self.update_light_status)
        rospy.Subscriber("/image_jpeg/compressed", CompressedImage, callback=self.cam_callback)
        self.prev_light_status = None 
        self.steer_pub = SteerPublisher()
        self.speed_pub = SpeedPublisher()
        self.has_changed_lane = False
        self.has_completed_mission_4 = True 

        #카메라 관련
        self.image_msg = CompressedImage()
        self.bridge = CvBridge()

    #카메라 콜백, 정지선 인식을 위함.
    def cam_callback(self,msg): ##카메라 콜백이 계속 켜져있으면 데이터가 너무 커질 수 있는 문제점이 있는데, 이를 해결할 방안을 모색해야함
        self.image_msg = msg
        cv_img = self.bridge.compressed_imgmsg_to_cv2(self.image_msg) #cv형태로 이미지 형식 변환
        hsv_img = cv2.cvtColor(cv_img,cv2.COLOR_BGR2HSV) #hsv이미지로 채널 변경

        #정지선이 하얀색이므로 노란색은 무시
        white_lower = np.array([0,0,192])
        white_upper = np.array([179,64,255])
        white_range = cv2.inRange(hsv_img,white_lower,white_upper)
        combined_img = cv2.bitwise_or(hsv_img,white_range)
        filtered_img = cv2.bitwise_and(cv_img,cv_img,mask=combined_img)

        corner_points_array = np.float32([[267,274],[46,426]
                                          ,[560,423],[370,274]]) #좌상, 좌하, 우하, 우상
        height, width = cv_img.shape[:2]
        img_params = np.float32([[width/2-150,0],[width/2-150,height],[width/2+150,height],[width/2+150,0]])
        mat = cv2.getPerspectiveTransform(corner_points_array,img_params)
        minverse = cv2.getPerspectiveTransform(img_params,corner_points_array) #원상복구 시키기 위한 변수
        image_transformed = cv2.warpPerspective(filtered_img,mat,(width,height))
        cv2.imshow("Bird_eye_view",image_transformed)

        #bird_eye_view상으로 정지선 인식 후 정지  -- > houghline의 기울기로 판단

    #신호등 콜백 , 인지
    def update_light_status(self, msg):
        current_light_status = msg.trafficLightStatus
        
        if self.has_changed_lane and self.prev_light_status != current_light_status:
            self.handle_light_change(current_light_status)

        if not self.has_changed_lane and self.has_completed_mission_4:
            self.change_lane()

        self.prev_light_status = current_light_status

    #신호등 판단제어
    def handle_light_change(self, light_status):
        if light_status == 1:
            self.stop_vehicle("빨간불입니다.정지")
        elif light_status == 16:
            self.stop_vehicle("파란불입니다.")
        elif light_status == 4:
            self.stop_vehicle("노란불입니다.")
        elif light_status == 33:
            print("좌회전신호입니다.")
            self.steer_pub.publish(0.331)
            self.speed_pub.publish(4)
            self.has_changed_lane = False

    #차량 정지 코드
    def stop_vehicle(self, message):
        print(message)
        self.steer_pub.publish(0.5)
        self.speed_pub.publish(0)

    #차선변경 
    def change_lane(self):
        print("lane_change_start")
        self.steer_pub.publish(0.35)
        self.speed_pub.publish(4)
        self.wait(1)
        self.steer_pub.publish(0.68)
        self.wait(1)
        self.steer_pub.publish(0.5)
        self.speed_pub.publish(0)
        self.wait(1)
        self.has_changed_lane = True
        self.has_completed_mission_4 = False
        print("lane_change_finish")

    #시간 관련
    def wait(self, duration):
        start_time = rospy.get_time()
        while rospy.get_time() - start_time < duration:
            pass

#조향
class SteerPublisher:
    def __init__(self):
        self.publisher = rospy.Publisher("/commands/servo/position", Float64, queue_size=1)
        self.message = Float64()

    def publish(self, value):
        self.message.data = value
        self.publisher.publish(self.message)
        print(f"steer: {self.message.data}")

#속도
class SpeedPublisher:
    def __init__(self):
        self.publisher = rospy.Publisher("/commands/motor/speed", Float64, queue_size=1)
        self.message = Float64()

    def publish(self, value):
        self.message.data = value * 300
        self.publisher.publish(self.message)
        print(f"speed: {self.message.data}")

#main함수
def main(): 
    rospy.init_node("TrafficLightNode")
    traffic_light = TrafficLight()
    while not rospy.is_shutdown():
        traffic_light.steer_pub.publish()
        traffic_light.speed_pub.publish()
    rospy.spin()

if __name__ == "__main__":
    main()
