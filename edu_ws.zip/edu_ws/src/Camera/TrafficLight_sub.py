#!/usr/bin/env python3
#-*- coding:utf-8 -*-

import rospy
from morai_msgs.msg import GetTrafficLightStatus
from std_msgs.msg import Float64 
import os
import time
from sensor_msgs.msg import CompressedImage
import numpy as np  
import cv2 
import matplotlib.pyplot as plt
from cv_bridge import CvBridge

#launch파일 수정해서, 승준이형 코드랑 같이 돌려보기,  추가적인 신호도 추가해서 작성

#SN000005 -- > traffic_light 
# 5 > 1 > 16 > 4 > 33(좌회전)

class Traffic_light_sub: 
    def __init__(self) :
        rospy.Subscriber("/GetTrafficLightStatus",GetTrafficLightStatus,callback=self.Traffic_light_CB)
        rospy.Subscriber("/image_jpeg/compressed", CompressedImage, callback=self.cam_callback)
        self.prev_light_status = None 
        self.steer_pub = steer_pub()
        self.speed_pub = speed_pub()
        self.traffic_trriger = False
        self.mission_4 = True #로터리 미션 완료 후, 오른쪽 차선으로 주행하고 있을때.
        self.lane = False
        self.left_sign = False #차선 변경 직후 바로 좌회전 신호를 받을때. 정지선 인식한 후 바로 출발. 정지x 

         #카메라 관련
        self.image_msg = CompressedImage()
        self.bridge = CvBridge()
    def Traffic_light_CB(self,msg):
        current_light_status = msg.trafficLightStatus
        # print(current_light_status) # int type
        
        if self.traffic_trriger == True : # 차선변경 이후 
            if self.prev_light_status is not None and self.prev_light_status != current_light_status:  #신호가 들어오고, 신호가 바뀌었을때 작동.
                print("traffic")
                if current_light_status == 5: #빨간불 + 노란불
                    print("곧 빨간불로 바뀝니다.")
                    self.steer_pub.steer = 0.5
                    self.speed_pub.speed = 0
                elif current_light_status == 1: #빨간불
                    print("빨간불입니다.정지")
                    self.steer_pub.steer = 0.5
                    self.speed_pub.speed = 0
                elif current_light_status == 16: # 파란불
                    print("파란불입니다.")
                    self.steer_pub.steer = 0.5 
                    self.speed_pub.speed = 0  
                elif current_light_status == 4: #노란불
                    print("노란불입니다.")
                    self.steer_pub.steer = 0.5  
                    self.speed_pub.speed = 0  
                elif current_light_status == 33: # 좌회전
                    print("좌회전신호입니다.")
                    self.steer_pub.steer = 0.331
                    self.speed_pub.speed = 4
                    # self.timing(6)
                    self.traffic_trriger = False  #traffic_light신호에 영향 x 다음 미션 수행 + 차선인식 수행
        else :
            if self.lane == False : 
                self.lane_change()  # 이게 문제가 아니고, 위 코드가 제대로 작동을 하지 x
            self.prev_light_status = msg.trafficLightStatus #이전 신호 상태 저장

    # 카메라 콜백, 정지선 인식을 위함.
    def cam_callback(self,msg): #이미지 불러와지는거까지 확인 . 버퍼링 심함. + 좌회전할때 영상이 안떴음.-->> 영상이 안뜬게 아니라 버퍼링이 심한거같은데...
        self.image_msg = msg
        cv_img = self.bridge.compressed_imgmsg_to_cv2(self.image_msg) #cv형태로 이미지 형식 변환
        hsv_img = cv2.cvtColor(cv_img,cv2.COLOR_BGR2HSV) #hsv이미지로 채널 변경     
        # cv2.imshow("image",cv_img)

        yellow_lower = np.array([15,128,0])
        yellow_upper = np.array([40,255,255])
        yellow_range = cv2.inRange(hsv_img,yellow_lower,yellow_upper)
        white_lower = np.array([0,0,192])
        white_upper = np.array([179,64,255])
        white_range = cv2.inRange(hsv_img,white_lower,white_upper)
        combined_img = cv2.bitwise_or(yellow_range,white_range)
        filtered_img = cv2.bitwise_and(cv_img,cv_img,mask=combined_img)

        corner_points_array = np.float32([[267,274],[46,426]
                                          ,[560,423],[370,274]]) #좌상, 좌하, 우하, 우상
        height, width = cv_img.shape[:2]
        img_params = np.float32([[width/2-150,0],[width/2-150,height],[width/2+150,height],[width/2+150,0]])
        mat = cv2.getPerspectiveTransform(corner_points_array,img_params)
        minverse = cv2.getPerspectiveTransform(img_params,corner_points_array) #원상복구 시키기 위한 변수
        image_transformed = cv2.warpPerspective(filtered_img,mat,(width,height))
        cv2.imshow("Bird_eye_view",image_transformed)

        if self.left_sign == False : 
            self.stop_line()
            self.left_sign = True
        else : 
            self.lane_follow()



        # bird_eye_view상으로 정지선 인식 후 정지  -- > houghline의 기울기로 판단
        # 정지선에서 정지를 한번 하고 나서 좌회전, 그리고 좌회전 후 차선인식 코드 실행. 

        cv2.waitKey(1)

    def lane_follow(self):
        pass
    def stop_line(self):
        pass


    #차선변경시 속도 감속. 차선인식 코드 킬지, 위 코드에 추가할지 생각. 
        # 조향,속도값은 건들지 말 것. 
    def lane_change(self):   #trafic 범위(로터리 통과 이후)내에 들어오면 차선 변경 작동. 이후 값 수정해야됨. 
        print("lane_change_start")
        if self.mission_4 == True and self.traffic_trriger == False :            
            self.steer_pub.steer = 0.25
            self.speed_pub.speed = 1.7
            self.timing(2.2)
            self.steer_pub.steer = 0.74
            self.timing(2.2)
            self.steer_pub.steer = 0.5
            self.speed_pub.speed = 0.5
            self.timing(2.2)

            self.mission_4 = False
            self.traffic_trriger = True
            self.lane = True
            print("lane_change_succes")
            
        print("lane_change_finish")

            # self.steer_pub.steer = 0.345
            # self.speed_pub.speed = 4


    def timing(self, count) :     #시간 세어주는 함수
        t_1 = rospy.get_time()
        t_2 = rospy.get_time()
        time = t_2 - t_1
        while time <= count :
            t_2 = rospy.get_time()
            time = t_2- t_1


class steer_pub: 
    def __init__(self) :
        self.pub = rospy.Publisher("/commands/servo/position",Float64,queue_size=1) 
        self.cmd_msg = Float64()
        self.rate = rospy.Rate(1)
        self.steer = 0.5

    def steering(self):
        self.cmd_msg.data = self.steer
        self.pub.publish(self.cmd_msg)
        print(f"steer:{self.cmd_msg.data}")
        self.rate.sleep()

class speed_pub: 
    def __init__(self) :
        self.pub = rospy.Publisher("/commands/motor/speed",Float64,queue_size=1) 
        self.cmd_msg = Float64()
        self.rate = rospy.Rate(1)
        self.speed = 0

    def motor_speed(self):
        self.cmd_msg.data = self.speed * 300
        self.pub.publish(self.cmd_msg)
        print(f"speed : {self.cmd_msg.data}")
        self.rate.sleep()

def main(): 
    rospy.init_node("TrafficLight_node")
    try : 
  
        class_TrafficLight = Traffic_light_sub()
        while not rospy.is_shutdown():
            class_TrafficLight.steer_pub.steering()
            class_TrafficLight.speed_pub.motor_speed()  
        rospy.spin()

    except rospy.ROSInterruptException:
        pass

if __name__== "__main__":
    main()


#1. 차선 변경후, trriger = true 변경, 
#2. 신호등 앞 정지선에서 정지 후, 신호 바뀌면 출발.
#3. 좌회선 후 출발.


#문제점 1. 계속 차선변경 코드가 콜백 함수 안에 들어가서 무한 반복됨.
    
# 코드 최적화, 간편화 필요 