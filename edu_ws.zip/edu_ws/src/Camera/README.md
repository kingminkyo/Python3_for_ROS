# Camera


### roslaunch rosbridge_server rosbridge_websocket.launch address:=127.0.0.1

센서 위치 값

1. 카메라
X : 0.30
Y : 0.00
Z : 0.10

2. 라이다
X : 0.115
Y : 0.00
Z : 0.12

3. GPS
X : 0.00
Y : 0.00 
Z : 0.11

4. IMU
X : 0.05
Y : 0.00
Z : 0.11
