#!/usr/bin/env python
#-*- coding: utf-8 -*-
#==========================================================================================================================================================
# 속도 1000일 때는 잘 돌아감. 주행차선 정지선 인덱싱 통한 차량 속도 UP 및 건녀편 차선 인덱싱 통한 정지선 없는 교차로에서 좌회전 할당하기
#==========================================================================================================================================================

import rospy
import cv2
from sensor_msgs.msg import CompressedImage
from sensor_msgs.msg import Image
from cv_bridge import CvBridge                  # ROS Image를 OpenCV의 Image로 변경하기 위해 필요한 코드
import numpy as np
from std_msgs.msg import Int32
from std_msgs.msg import Float64
from std_msgs.msg import Int8MultiArray
from sensor_msgs.msg import CameraInfo
from display import draw_arrow
import matplotlib.pyplot as plt
import time
import warnings

class CameraReceiver():
    def __init__(self):
        rospy.loginfo("Camera Receiver object is created")
        # print('11111111111111111111111')
        rospy.Subscriber("/image_jpeg/compressed", CompressedImage, self.camera_callback)
        # rospy.Subscriber("/commands/motor/speed", Float64, self.speed_callback)
        # rospy.Subscriber("/commands/servo/position", Float64, self.steer_callback)
        self.bridge = CvBridge()
        self.initialized = False                                             
        # self.lane_moment_pub = rospy.Publisher("center_lane_moment_x", Int32, queue_size=3)
        self.speed_pub = rospy.Publisher("/commands/motor/speed", Float64, queue_size=1)
        self.steer_pub = rospy.Publisher("/commands/servo/position", Float64, queue_size=1)
        # self.steer_pub = rospy.Publisher("/request/steer/angle", Float64, queue_size=1)
        # self.speed_pub = rospy.Publisher("/request/motor/speed", Float64, queue_size=1)
        # self.steer_pub = rospy.Publisher("/request/steer/angle/node1", Float64, queue_size=1)
        self.lane_pub = rospy.Publisher("/request/lane", Int32, queue_size=1)
        
        self.motor_steer = 0
        self.P_param = 500

        self.smoothing_factor = 0.7
        # self.stop_line = StopLine()
        self.frame_cnt = 0
        self.print_cnt = True

#====================정지선 관련=========================
        self.vertical_line_threshold = 10 #정지선 Houghline 개수 
        self.stop_detected_index = 0
        self.last_time_updated = 0
        self.stop_line_action = False
#====================정지선 관련=========================
        
        self.current_speed = 0
        self.current_angle = 0.535

        self.old_left_fit = None
        self.old_right_fit = None
        # rospy.loginfo("Initialization completed successfully")

    def speed_callback(self, msg):
        # print('11111111111111111111111')
        

        self.current_speed = msg.data
        
    def steer_callback(self, msg):
        self.current_angle = msg.data

    def angle_filter(self, current_angle, computed_angle, max_angle_change):
        angle_diff = abs(computed_angle - current_angle)


        if angle_diff > max_angle_change:  # 급격한 변화가 있는 경우
            return current_angle  # 현재 차량 각도를 사용
        
        else:
            return computed_angle  # 계산된 주행 각도를 사용

    def plothistogram(self, image):

        bottom_quarter = image[image.shape[0] * 3 // 4:, :]
        blurred_image = cv2.GaussianBlur(bottom_quarter, (5, 5), 0)
        histogram = np.sum(blurred_image, axis=0)
        midpoint = int(histogram.shape[0] / 2)
        leftbase = np.argmax(histogram[:midpoint])
        rightbase = np.argmax(histogram[midpoint:]) + midpoint

        return leftbase, rightbase

    def find_lane_divider(self, binary_warped):
        # 이 부분에서 중앙 기준으로 좌우 나누고, 흰색 픽셀 수가 어디에 많은지를 계산하는 함수입니다.
        # 아래는 예시로 간단하게 구현한 것이며, 실제로 사용하는 이미지에 따라 파라미터와 로직을 조정해야 합니다.
        mid_point = binary_warped.shape[1] // 2
        left_pixels = np.sum(binary_warped[:, :mid_point] == 255)
        right_pixels = np.sum(binary_warped[:, mid_point:] == 255)

        return left_pixels, right_pixels

    def classify_lane(self, left_pixels, right_pixels):
        # 이 함수에서는 좌우 픽셀 수에 따라 현재 위치를 1차선과 2차선으로 구분합니다.
        # 예시로 1차선은 좌측에 있을 때, 2차선은 우측에 있을 때로 구분합니다.
        if left_pixels > right_pixels:
            # return "1st lane"  # 1차선 (가운데로부터 좌측에 위치)
            return 1  # 1차선 (가운데로부터 좌측에 위치)
        else:
            # return "2nd lane"  # 2차선 (가운데로부터 우측에 위치)
            return 2  # 2차선 (가운데로부터 우측에 위치)

    def slide_window_search(self, masked, left_current, right_current):

        # print("right_current : ",right_current)
        # print("left_current : ",left_current)

        out_img = np.dstack((masked, masked, masked))
        # out_img = masked

        # nwindows = 5
        nwindows = 10
        window_height = int(masked.shape[0] / nwindows) # 120
        nonzero = masked.nonzero()
        nonzero_y = np.array(nonzero[0])
        nonzero_x = np.array(nonzero[1])
        # margin = 100
        margin = 80
        # minpix = 50
        minpix = 20
        left_lane = []  # 왼쪽 차선만 검출하는 배열로 수정
        right_lane = []  # 오른쪽 차선만 검출하는 배열로 수정

        # Define color variable for drawing rectangles
        color = [0, 255, 0]
        thickness = 2

        for w in range(nwindows):
            win_y_low = masked.shape[0] - (w + 1) * window_height
            win_y_high = masked.shape[0] - w * window_height
            win_xleft_low = left_current - margin
            win_xleft_high = left_current + margin
            win_xright_low = right_current - margin
            win_xright_high = right_current + margin

            cv2.rectangle(out_img, (win_xleft_low, win_y_low), (win_xleft_high, win_y_high), color, thickness)
            cv2.rectangle(out_img, (win_xright_low, win_y_low), (win_xright_high, win_y_high), color, thickness)

            cv2.imshow("out_img",out_img)

            good_left = ((nonzero_y >= win_y_low) & (nonzero_y < win_y_high) & (nonzero_x >= win_xleft_low) & (nonzero_x < win_xleft_high)).nonzero()[0]
            good_right = ((nonzero_y >= win_y_low) & (nonzero_y < win_y_high) & (nonzero_x >= win_xright_low) & (nonzero_x < win_xright_high)).nonzero()[0]

            left_lane.append(good_left)
            right_lane.append(good_right)

            

        left_lane = np.concatenate(left_lane) if len(left_lane) > 0 else None
        right_lane = np.concatenate(right_lane) if len(right_lane) > 0 else None

        if left_lane is None or right_lane is None:
            return None

        leftx = nonzero_x[left_lane]
        lefty = nonzero_y[left_lane]
        rightx = nonzero_x[right_lane]
        righty = nonzero_y[right_lane]
        
        try:
            left_fit = np.polyfit(lefty, leftx, 2)
            right_fit = np.polyfit(righty, rightx, 2)

            self.old_left_fit = left_fit
            self.old_right_fit = right_fit

            ploty = np.linspace(0, masked.shape[0] - 1, masked.shape[0])
            left_fitx = left_fit[0] * ploty ** 2 + left_fit[1] * ploty + left_fit[2]
            right_fitx = right_fit[0] * ploty ** 2 + right_fit[1] * ploty + right_fit[2]

            # print("보정 전 좌측:", left_fitx[-1])
            # print("보정 전 우측:", right_fitx[-1])
            # print("보정 전 차이:",right_fitx[-1] - left_fitx[-1])
            # print("=")
            # 검출된 차선들의 중심 위치의 평균과 차선 사이의 차이를 확인하여 조정
            avg_position = (left_fitx[-1] + right_fitx[-1]) / 2
            if avg_position <= 320 and abs(right_fitx[-1] - left_fitx[-1]) < 130:
                # 예: 오른쪽 차선을 50픽셀만큼 오른쪽으로 이동시키기
                # print("오른쪽으로 바로잡자 현재는: ",abs(right_fitx[-1] - left_fitx[-1]) )
                # left_fitx -= 150
                right_fitx += 50
            elif avg_position > 320 and abs(right_fitx[-1] - left_fitx[-1]) < 130:
                # 예: 왼쪽 차선을 50픽셀만큼 왼쪽으로 이동시키기
                # print("왼쪽으로 바로잡자 현재는: ", abs(right_fitx[-1] - left_fitx[-1]) )
                
                left_fitx -= 50
                # right_fitx +=150

            if left_fitx[-1] >= right_fitx[1] or (abs(right_fitx[1] - left_fitx[-1]) < 10 ) or (abs(right_fitx[1] - right_fitx[-1]) > 100):
                right_fitx = left_fitx + 200
                # print("오른쪽 보정")


            elif left_fitx[1] >= right_fitx[-1] or (abs(right_fitx[-1] - left_fitx[1]) < 10 ) or (abs(left_fitx[1] - left_fitx[-1]) > 100):
                left_fitx = right_fitx - 200
                # left_fitx = right_fitx - 200
                # print("왼쪽 보정")

            ltx = np.trunc(left_fitx)
            rtx = np.trunc(right_fitx)

            out_img[nonzero_y[left_lane], nonzero_x[left_lane]] = [255, 0, 0]
            out_img[nonzero_y[right_lane], nonzero_x[right_lane]] = [0, 0, 255]
            # print("보정 후 좌측:", left_fitx[-1])
            # print("보정 후 우측:", right_fitx[-1])
            # print("보정 전 차이:",right_fitx[-1] - left_fitx[-1])
            # print("================")
            ret = {'left_fitx': ltx, 'right_fitx': rtx, 'ploty': ploty}

            return ret

        except Exception as e:
            # print('11111111111111111111111')
            
            # left_fit = self.old_left_fit
            # right_fit = self.old_right_fit

            # self.old_left_fit = left_fit
            # self.old_right_fit = right_fit

            # ploty = np.linspace(0, masked.shape[0] - 1, masked.shape[0])
            # left_fitx = left_fit[0] * ploty ** 2 + left_fit[1] * ploty + left_fit[2]
            # right_fitx = right_fit[0] * ploty ** 2 + right_fit[1] * ploty + right_fit[2]

            # # print("보정 전 좌측:", left_fitx[-1])
            # # print("보정 전 우측:", right_fitx[-1])
            # # print("보정 전 차이:",right_fitx[-1] - left_fitx[-1])
            # # print("=")
            # # 검출된 차선들의 중심 위치의 평균과 차선 사이의 차이를 확인하여 조정
            # avg_position = (left_fitx[-1] + right_fitx[-1]) / 2
            # if avg_position <= 320 and abs(right_fitx[-1] - left_fitx[-1]) < 170:
            #     # 예: 오른쪽 차선을 50픽셀만큼 오른쪽으로 이동시키기
            #     # print("오른쪽으로 바로잡자 현재는: ",abs(right_fitx[-1] - left_fitx[-1]) )
            #     # left_fitx += 170
            #     right_fitx += 250
            # elif avg_position > 320 and abs(right_fitx[-1] - left_fitx[-1]) < 170:
            #     # 예: 왼쪽 차선을 50픽셀만큼 왼쪽으로 이동시키기
            #     # print("왼쪽으로 바로잡자 현재는: ", abs(right_fitx[-1] - left_fitx[-1]) )
                
            #     left_fitx -= 250
            #     # right_fitx -=150

            # # if left_fitx[-1] >= right_fitx[1] or (abs(right_fitx[1] - left_fitx[-1]) < 10 ) or (abs(right_fitx[1] - right_fitx[-1]) > 100):
            # #     right_fitx = left_fitx + 100
            # #     print("오른쪽 보정")


            # # elif left_fitx[1] >= right_fitx[-1] or (abs(right_fitx[-1] - left_fitx[1]) < 10 ) or (abs(left_fitx[1] - left_fitx[-1]) > 100):
            # #     left_fitx = right_fitx - 100
            # #     print("왼쪽 보정")

            # ltx = np.trunc(left_fitx)
            # rtx = np.trunc(right_fitx)

            # out_img[nonzero_y[left_lane], nonzero_x[left_lane]] = [255, 0, 0]
            # out_img[nonzero_y[right_lane], nonzero_x[right_lane]] = [0, 0, 255]
            # # print("보정 후 좌측:", left_fitx)
            # # print("보정 후 우측:", right_fitx)
            # # print("보정 전 차이:",right_fitx[-1] - left_fitx[-1])
            # print("================")
            # ret = {'left_fitx': ltx, 'right_fitx': rtx, 'ploty': ploty}

            # return ret
            # print(f"Error in Camera Receiver initialization: {str(e)}")
            # self.speed_pub.publish(Float64(1000))

            return False    






    def draw_lane_lines(self, original_image, warped_image, Minv, draw_info):
        # print("================")

        left_fitx = draw_info['left_fitx']
        right_fitx = draw_info['right_fitx']
        ploty = draw_info['ploty']

        if left_fitx is None or right_fitx is None:
            return original_image

        left_ = left_fitx[120:150]
        right_ = right_fitx[120:150]

        left_x = np.mean(left_)
        right_x = np.mean(right_)
        left = left_x - float(320)
        right = right_x - float(320)
        ref_dist = left + right

        warp_zero = np.zeros_like(warped_image).astype(np.uint8)
        color_warp = np.dstack((warp_zero, warp_zero, warp_zero))

        pts_left = np.array([np.transpose(np.vstack([left_fitx, ploty]))])
        pts_right = np.array([np.flipud(np.transpose(np.vstack([right_fitx, ploty])))])
        pts = np.hstack((pts_left, pts_right))

        mean_x = np.mean((left_fitx, right_fitx), axis=0)
        pts_mean = np.array([np.flipud(np.transpose(np.vstack([mean_x, ploty])))])

        k = np.int_([pts_mean])
        ref_angle = float((k[0][0][150][0] - k[0][0][120][0])/30)

        cv2.fillPoly(color_warp, np.int_([pts]), (255, 255, 255))
        cv2.fillPoly(color_warp, k, (0, 0, 255))
        cv2.circle(color_warp, (k[0][0][150][0],k[0][0][150][1]), 5, (0,255,0), -1)
        cv2.circle(color_warp, (k[0][0][10][0],k[0][0][10][1]), 5, (0,255,0), -1)

        newwarp = cv2.warpPerspective(color_warp, Minv, (original_image.shape[1], original_image.shape[0]))
        result = cv2.addWeighted(original_image, 1, newwarp, 0.4, 0)

        return pts_mean, result, k[0][0][150][0]
    
#=========================================================정지선 인덱싱=========================================================
    
    def reset_stop_line_action(self, event):
        self.stop_line_action= False
#=========================================================정지선 인덱싱=========================================================

    def camera_callback(self, _data):
        self.frame_cnt +=1
        if self.frame_cnt % 2 != False:
            pass
        else:
            # self.frame_cnt = 0
            # rospy.set_param('normal_drive_mode',True)
            
            if self.initialized == False:       # 아래의 코드는 처음 실행했을 때, 한번만 실행되어야하므로 self.initialized를 사용해서 처음에만 실행되도록 짜준 코드
                cv2.namedWindow("hsv", cv2.WINDOW_NORMAL)       # Simulator_Image를 원하는 크기로 조정가능하도록 만드는 코드
                # 흰색 차선을 검출할 때, 이미지를 보면서 트랙바를 움직이면서 흰색선이 검출되는 정도를 파악하고 코드안에 그 수치를 넣어준다.
                cv2.createTrackbar('low_H', 'hsv', 0, 255, nothing)    # Trackbar 만들기
                cv2.createTrackbar('low_S', 'hsv', 0, 255, nothing)
                # cv2.createTrackbar('low_V', 'hsv', 134, 255, nothing)
                # cv2.createTrackbar('low_V', 'hsv', 48, 255, nothing) ### 23.08.12  night
                cv2.createTrackbar('low_V', 'hsv', 100, 255, nothing) ### 
                cv2.createTrackbar('high_H', 'hsv', 255, 255, nothing)    # Trackbar 만들기
                cv2.createTrackbar('high_S', 'hsv', 255, 255, nothing)
                cv2.createTrackbar('high_V', 'hsv', 255, 255, nothing)
                self.initialized = True

            cv_image = self.bridge.compressed_imgmsg_to_cv2(_data)
            # np_arr = np.frombuffer(msg.data, np.uint8)
            # image = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
            # cv2.imshow('test4',image)
            
            
            p1 = [300, 290]  # 좌상
            p2 = [290, 330] # 좌하
            p3 = [340, 290] # 우상
            p4 = [350, 330]  # 우하
            
            # corners_point_arr는 변환 이전 이미지 좌표 4개 
            corner_points_arr = np.float32([p1, p2, p3, p4])
            height = 480
            width = 640

            image_p1 = [0, 0]
            image_p2 = [0, height]
            image_p3 = [width, 0]
            image_p4 = [width, height]

            image_params = np.float32([image_p1, image_p2, image_p3, image_p4])

            mat = cv2.getPerspectiveTransform(corner_points_arr, image_params)
            # mat = 변환행렬(3*3 행렬) 반
            image_transformed = cv2.warpPerspective(cv_image, mat, (width, height))
            # cv2.imshow('tes3',image_transformed)
            

            roi_top = 0
            roi_bottom = 340
            roi_mask = np.zeros_like(cv_image[:, :, 0])
            roi_mask[:, :] = 255
            stop_line_region = cv2.bitwise_and(image_transformed, image_transformed, mask=roi_mask)
            # cv2.circle(cv_image, p1, 2, (0, 255, 0), -1)
            # cv2.circle(cv_image, p2, 2, (0, 255, 0), -1)
            # cv2.circle(cv_image, p3, 2, (0, 255, 0), -1)
            # cv2.circle(cv_image, p4, 2, (0, 255, 0), -1)

            # cv2.imshow('wunbon',cv_image)

            gray_frame = cv2.cvtColor(stop_line_region, cv2.COLOR_BGR2GRAY)
            blur_img = cv2.GaussianBlur(gray_frame, (5, 5), 5)
            # threshold1 증가하면 떨어져 있는 직선끼리 서로 잘 연결됨, threshold2 올리면 올릴수록 더 뚜렷한 직선만 검출
            # edges = cv2.Canny(blur_img, threshold1=10, threshold2=25) # 어두컴컴 적운형 구름 일요일, 오후 6시
            # edges = cv2.Canny(blur_img, threshold1=15, threshold2=50) # 해가 쨍한데 구름에 가려졌을 때
            edges = cv2.Canny(blur_img, threshold1=25, threshold2=60) # 중간
            # edges = cv2.Canny(blur_img, threshold1=40, threshold2=75) # 해가 구름에 안가려져서 쨍할 때
            # cv2.imshow('edge',edges)

            stop_lines = cv2.HoughLinesP(edges, rho=1, theta=np.pi/180, threshold=20, minLineLength=50, maxLineGap=10)
            output_image = np.copy(stop_line_region)

            vertical_lines = 0

            if stop_lines is not None:
                for line in stop_lines:
                    x1, y1, x2, y2 = line[0]

                    slope = (y2 - y1) / (x2 - x1 + 1e-5)  

                    slope_threshold = 0.1
                    if slope_threshold >= abs(slope)  :
                        cv2.line(output_image, (x1, y1), (x2, y2), (0, 0, 255), 2)
                        vertical_lines += 1 
                        # print(vertical_lines)
                    else:
                        pass  
                if vertical_lines >= self.vertical_line_threshold and time.time() - self.last_time_updated >= 2:
                    self.stop_detected_index += 1
                    self.last_time_updated = time.time()
                    self.stop_line_action = True
                    rospy.Timer(rospy.Duration(3.5), self.reset_stop_line_action, oneshot=True)


            
                    

                    # print('Stop !')

                # cv2.imshow('Detected Stop Lines', output_image)
            # if rospy.get_param('stop_line_mode'):
            cv2.imshow('stop_line',output_image)
            print("self.stop_line_action : ", self.stop_line_action)
            print("self.stop_detected_index : ", self.stop_detected_index)

            # cv2.waitKey(1)

#============================================================================================================================================
            #============== 카메라 띄우기 =========================
            # cv_image = self.bridge.compressed_imgmsg_to_cv2(_data)
            # cv2.imshow("rect_camera", cv_image)                                                              # wun bon
            # canny = self.canny(cv_image)  
            # cv2.imshow("canny", canny)

            #====================================================
            # 시점변환부터
            
            (h, w) = (cv_image.shape[0], cv_image.shape[1])
            Width = 640
            Height = 480
            # source = np.float32([[275,260], [0, 420], [365, 260], [640, 420]]) #교육  # [x,y]                        #     2  good  jom gip da
            # source = np.float32([[240,290], [20, 420], [440, 290], [620, 420]]) #슬라이딩  # [x,y]                        #     2  good  jom gip da
            # source = np.float32([[275, 328], [155, 440], [365, 328], [485, 440]]) #여름   # [x,y]                        #     2  good  jom gip da
            # source = np.float32([[250,310], [20, 420], [390, 310], [620, 420]])  # 승준0119  # [x,y]                        #     2  good  jom gip da
            source = np.float32([[240,290], [150, 420], [400, 290], [480, 420]]) # 승준1  # [x,y] 여름트랙 반시계 잘 돔                        #     2  good  jom gip da
            # source = np.float32([[200,290], [0, 420], [440, 290], [640, 420]]) # 승준2  # [x,y]                        #     2  good  jom gip da
            for point in source:
                cv2.circle(cv_image, tuple(map(int, point)), 1, (0, 255, 0), -1)
                      #     2  good  jom gip da
            # destination = np.float32([[60, 10], [0, 470], [580, 10], [640, 470]]) # 승준2
            # destination = np.float32([[110, 0], [110, 470], [550, 0], [550, 470]]) # 승준0119 3,/ 4 번째를 키우면 오른쪽 여백이 작아진다..?
            destination = np.float32([[235, 10], [235, 470], [405, 10], [405, 470]]) # 여름트랙 반시계 잘 돔
            # destination = np.float32([[50, 10], [100, 470], [480, 10], [480, 470]]) # 승준1 3, 4 번째를 키우면 오른쪽 여백이 작아진다..?
            # destination = np.float32([[80, 0], [80, 480], [560, 0], [560, 480]]) #교육

            # 변환 행렬을 구하기 위해서 쓰는 함수
            transform_matrix = cv2.getPerspectiveTransform(source, destination)
            # minv값은 마지막에 warpping된 이미지를 다시 원근감을 
            minv = cv2.getPerspectiveTransform(destination, source)
            # 변환 행렬값을 적용하여 최종 결과 이미지를 얻을 수 있다.
            _image = cv2.warpPerspective(cv_image, transform_matrix, (w, h))
            # cv2.imshow("warp_image", _image)                                                                      # jja bu

            # # ===============================================================
            
            hsv = cv2.cvtColor(_image, cv2.COLOR_BGR2HSV)
            

            low_H = cv2.getTrackbarPos('low_H', 'hsv')
            low_S = cv2.getTrackbarPos('low_S', 'hsv')
            low_V = cv2.getTrackbarPos('low_V', 'hsv')
            high_H = cv2.getTrackbarPos('high_H', 'hsv')
            high_S = cv2.getTrackbarPos('high_S', 'hsv') 
            high_V = cv2.getTrackbarPos('high_V', 'hsv')

            lower_lane = np.array([low_H, low_S, low_V])
            upper_lane = np.array([high_H, high_S, high_V])
            blur_img = cv2.GaussianBlur(hsv, (3, 3), 5)
            self.masked = cv2.inRange(blur_img, lower_lane, upper_lane)
        
            # cv2.imshow("lane_image", self.masked)
            # cv2.moveWindow("lane_image", 700, 300)

            x = int(self.masked.shape[1])    # 이미지 가로
            y = int(self.masked.shape[0])    # 이미지 세로

            #한붓그리기
            _shape = np.array(
                [[int(0.15*x), int(y)], [int(0.15*x), int(0.1*y)], [int(0.49*x), int(0.1*y)], [int(0.49*x), int(y)], [int(0.513*x), int(y)], [int(0.513*x), int(0.1*y)], [int(0.75*x), int(0.1*y)], [int(0.75*x), int(y)], [int(0.4*x), int(y)]]
            )

            mask2 = np.zeros_like(self.masked)
            #print(self.masked.shape)

            if len(self.masked.shape) > 2:
                channel_count = self.masked.shape[2]
                ignore_mask_color = (255, ) * channel_count
            else:
                ignore_mask_color = 255

            cv2.fillPoly(mask2, np.int32([_shape]), ignore_mask_color)
            #cv2.imshow("lane1", mask2)    
            masked_image = cv2.bitwise_and(self.masked, mask2)

            leftbase, rightbase = self.plothistogram(masked_image)

            left_pixels, right_pixels = self.find_lane_divider(masked_image)
            current_lane = self.classify_lane(left_pixels, right_pixels)


            # # ## histogram 기반 window roi 영역
            draw_info = self.slide_window_search(masked_image, leftbase, rightbase)
            
            
            if draw_info == False:
                cv2.imshow("result", cv_image) 
                self.speed_pub.publish(Float64(1000))
                # cv2.moveWindow("result", 1400, 300)
            else:
                meanPts, result, center_x = self.draw_lane_lines(cv_image, masked_image, minv, draw_info)
                
                self.lane_pub.publish(Int32(center_x))

                # Calculate the error from the center of the image
                # error = center_x - (cv_image.shape[1] // 2)
                # normalized_error = error / (cv_image.shape[1] // 2)

                steer_scale = 1.1
                # center_x = center_x + 27
                error = center_x - (cv_image.shape[1] // 2)
                # print("center_x", center_x)
                normalized_error = error / (cv_image.shape[1] // 2)
                steer_angle = 0.4628 + steer_scale * normalized_error

                # Clip the steering angle to be between 0.0 and 1.0
                steer_angle = np.clip(steer_angle, 0.0, 1.0)

                new_steer = steer_angle

                # Apply linear smoothing
                self.motor_steer = (1 - self.smoothing_factor) * self.motor_steer + self.smoothing_factor * new_steer
                steer_angle = self.angle_filter(self.current_angle, self.motor_steer, 0.7)
                
                # print(self.current_angle)

                if self.stop_detected_index in [1, 2, 4, 7] and self.stop_line_action :
                    # self.speed_pub.publish(3000)
                    # rospy.Timer(rospy.Duration(0.5), self.reset_speed_straight, oneshot=True)
                    self.speed_pub.publish(1000)

                    self.steer_pub.publish(steer_angle)
                    # self.steer_pub.publish(0.5)
                    pass
                
                elif self.stop_detected_index in [3, 5, 6, 8] and self.stop_line_action :
                    
                    self.speed_pub.publish(1000)
                    self.steer_pub.publish(steer_angle)
                    rospy.Timer(rospy.Duration(5), self.reset_speed_corner, oneshot=True)
            
                else:
                    if self.current_angle is None:
                        self.steer_pub.publish(Float64(self.motor_steer))
                    # self.steer_pub.publish(Float64(steer_angle))
                    # print("self.motor_steer : ",self.motor_steer)
                    else :
                        self.steer_pub.publish(Float64(steer_angle))
                        # self.speed = 1500 - self.P_param * abs(0.5-steer_angle)
                        # self.speed_pub.publish(Float64(self.speed))
                        self.speed_pub.publish(1000)
                    # self.steer_pub.publish(Float64(self.motor_steer))
                    # print("steer_angle : ",steer_angle)
                # self.lane.publish(Float64(current_lane))

                if self.print_cnt :
                        print("[일반 주행] 일반 주행 중")
                        self.print_cnt = False

                # # ## 원본 이미지에 라인 넣기
                meanPts, result, x1 = self.draw_lane_lines(cv_image, masked_image, minv, draw_info)
                # self.lane_moment_pub.publish(Int(x1))

                if self.current_angle is not None:
                    result = draw_arrow(result, self.current_angle, self.current_speed)
                else:
                    ############## 일단 패스. 생각해보자.
                    pass
                
                cv2.imshow("result", result)
                # cv2.moveWindow("result", 1400, 300)

        cv2.waitKey(1) 
        
    def reset_speed_corner(self, event):
        self.speed_pub.publish(self.speed)
    
    def reset_speed_straight(self, event):
        self.speed_pub.publish(self.speed)

    

def nothing():
    pass

# 실제 코드 동작 시, 실행할 코드
def run():
    rospy.init_node("path_tracking")     # camera_example이라는 이름으로 노드를 ROS_MASTER에 등록해주는 코드 (이름이 겹치지만 않으면 됨) 
    warnings.filterwarnings("ignore", category=np.RankWarning)
    new_class = CameraReceiver()          # 실제 동작을 담당할 Object
    rospy.spin()                         # ROS Node가 종료되지 않고, Callback 함수를 정상적으로 실행해주기 위한 부분 (코드를 유지하면서, 지속적으로 subscriber를 호출해주는 함수)

if __name__ == '__main__':               # 해당 Python 코드를 직접 실행할 때만 동작하도록 하는 부분
    run()    
