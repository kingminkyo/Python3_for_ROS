#!/usr/bin/env python3
#-*- coding: utf-8 -*-

import cv2
import numpy as np
import rospy
from sensor_msgs.msg import CompressedImage
from cv_bridge import CvBridge
from std_msgs.msg import Float64
import time

class StopLine_1():
    def __init__(self):
        rospy.Subscriber("/image_jpeg/compressed", CompressedImage, self.image_callback_1)
        self.speed_pub = rospy.Publisher("/commands/motor/speed", Float64, queue_size=1)
        self.steer_pub = rospy.Publisher("/commands/servo/position", Float64, queue_size=1)
        # self.speed_pub = rospy.Publisher("/request/motor/speed", Float64, queue_size=1)
        # self.steer_pub = rospy.Publisher("/request/steer/angle", Float64, queue_size=1)
        self.bridge = CvBridge()

        self.print_cnt_1 = True
        self.print_cnt_2 = True
        self.print_cnt_3 = True
        self.print_cnt_4 = True

        #====================정지선 관련=========================
        self.stop_line_apart = 6                    

        self.vertical_line_threshold = 10 #정지선 Houghline 개수 
        self.stop_detected_index_1 = 0
        self.last_time_updated = 0
        self.last_time_updated_2 = 0
        self.stop_line_action = False
        self.stop_line_action_3 = True
        self.stop_line_action_4 = False
        
        
        self.is_turning_left = False
        #====================정지선 관련=========================

    def reset_stop_line_action(self, event):
        self.stop_line_action= False

    def reset_stop_line_action_3(self, event):
        self.stop_line_action_3 = True
    
    def reset_stop_line_action_4(self, event):
        self.stop_line_action_4 = False

    def image_callback_1(self,msg,_data):
        stop_line_2_mode = rospy.get_param('stop_line_2_mode')

        if stop_line_2_mode:
            pass
        else:

            cv_image = self.bridge.compressed_imgmsg_to_cv2(_data)
            # np_arr = np.frombuffer(msg.data, np.uint8)
            # image = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
            # cv2.imshow('test4',image)
            
            
            #=========================================================정지선 인덱싱=========================================================            
            p1 = [300, 280]  # 좌상
            p2 = [290, 310] # 좌하
            p3 = [340, 280] # 우상
            p4 = [350, 310]  # 우하
            
            # corners_point_arr는 변환 이전 이미지 좌표 4개 
            corner_points_arr = np.float32([p1, p2, p3, p4])
            height = 480
            width = 640

            image_p1 = [0, 0]
            image_p2 = [0, height]
            image_p3 = [width, 0]
            image_p4 = [width, height]

            image_params_1 = np.float32([image_p1, image_p2, image_p3, image_p4])


            mat_1 = cv2.getPerspectiveTransform(corner_points_arr, image_params_1)
            # mat = 변환행렬(3*3 행렬) 반
            image_transformed_1 = cv2.warpPerspective(cv_image, mat_1, (width, height))
            # cv2.imshow('tes3',image_transformed_1)

            roi_mask = np.zeros_like(cv_image[:, :, 0])
            roi_mask[:, :] = 255
            stop_line_region_1 = cv2.bitwise_and(image_transformed_1, image_transformed_1, mask=roi_mask)
            # cv2.circle(cv_image, p1, 2, (0, 255, 0), -1)
            # cv2.circle(cv_image, p2, 2, (0, 255, 0), -1)
            # cv2.circle(cv_image, p3, 2, (0, 255, 0), -1)
            # cv2.circle(cv_image, p4, 2, (0, 255, 0), -1)
            # cv2.imshow('wunbon',cv_image)

            gray_frame_1 = cv2.cvtColor(stop_line_region_1, cv2.COLOR_BGR2GRAY)
            blur_img_1 = cv2.GaussianBlur(gray_frame_1, (5, 5), 5)
            # threshold1 증가하면 떨어져 있는 직선끼리 서로 잘 연결됨, threshold2 올리면 올릴수록 더 뚜렷한 직선만 검출
            # edges = cv2.Canny(blur_img_1, threshold1=10, threshold2=25) # 어두컴컴 적운형 구름 일요일, 오후 6시
            # edges = cv2.Canny(blur_img_1, threshold1=15, threshold2=50) # 해가 쨍한데 구름에 가려졌을 때
            edges_1 = cv2.Canny(blur_img_1, threshold1=25, threshold2=60) # 중간
            # edges_1 = cv2.Canny(blur_img_1, threshold1=40, threshold2=75) # 해가 구름에 안가려져서 쨍할 때
            # cv2.imshow('edge',edges_1)

            stop_lines_1 = cv2.HoughLinesP(edges_1, rho=1, theta=np.pi/180, threshold=20, minLineLength=120, maxLineGap=20)
            output_image_1 = np.copy(stop_line_region_1)

            vertical_lines_1 = 0

            if stop_lines_1 is not None:
                for line in stop_lines_1:
                    x1, y1, x2, y2 = line[0]

                    slope = (y2 - y1) / (x2 - x1 + 1e-5)  

                    slope_threshold = 0.1
                    if slope_threshold >= abs(slope)  :
                        cv2.line(output_image_1, (x1, y1), (x2, y2), (0, 0, 255), 2)
                        vertical_lines_1 += 1 
                        # print(vertical_lines_1)
                    else:
                        pass  
                if vertical_lines_1 >= self.vertical_line_threshold and time.time() - self.last_time_updated >= 3 and not self.stop_line_action_2 :  # 3초동안 임계값 넘어도 +1 안됨
                    self.stop_detected_index_1 += 1
                    self.last_time_updated = time.time()
                    self.stop_line_action = True
                    self.stop_line_action_3 = False
                    self.stop_line_action_4 = True
                    print("[현재 차선]정지선 발견")
                    rospy.Timer(rospy.Duration(1.5), self.reset_stop_line_action, oneshot=True) #직빨 시간
                    rospy.Timer(rospy.Duration(1.2), self.reset_stop_line_action_3, oneshot=False) #7번 인덱스 우회전 시간 1.5초 있다가 우회전 시작
                    rospy.Timer(rospy.Duration(2), self.reset_stop_line_action_4, oneshot=True) #7번 인덱스 우회전 시간 액션 4 - 액션 3 시간동안 우회전
                    # print('Stop !')

                # cv2.imshow('Detected Stop Lines', output_image_1)
            # if rospy.get_param('stop_line_mode'):
            # cv2.imshow('stop_line',output_image_1)
            # print("self.stop_detected_index_1 : ", self.stop_detected_index_1)
            # print("self.stop_line_action : ", self.stop_line_action)
            # print("self.stop_line_action_3 : ", self.stop_line_action_3)
            # print("self.stop_line_action_4 : ", self.stop_line_action_4)

            # cv2.waitKey(1)
            if self.stop_detected_index_1 in [1, 2, 9] and self.stop_line_action :
                self.speed_pub.publish(3000)
                self.steer_pub.publish(0.5)
                pass

            elif self.stop_detected_index_1 in [3] and self.stop_line_action :
                if self.print_cnt_1:
                    print("[3번째 index] : 주행중")
                    self.print_cnt_1 = False
                pass
        
            elif self.stop_detected_index_1 == 4 and self.stop_line_action :
                self.speed_pub.publish(3000)
                self.steer_pub.publish(0.5)
                if self.print_cnt_2:
                    print("[4번째 index] : 건너편 정지선 인지 구간")
                    self.print_cnt_2 = False
                pass

            elif self.stop_detected_index_1 == 5 and self.stop_line_action :
                self.speed_pub.publish(0)
                if self.print_cnt_3:
                    print("[5번째 index] : 로터리 앞 정지")
                    self.print_cnt_3 = False
                
            elif self.stop_detected_index_1 == 7 and self.stop_line_action :
                self.speed_pub.publish(0)
                if self.print_cnt_4:
                    print("[7번째 index] : 교차로 지나서 정지")
                    self.print_cnt_4 = False
                
                # cv2.imshow('Detected Stop Lines', output_image)
            # if rospy.get_param('stop_line_mode'):
                # cv2.imshow('result',output_image)
            cv2.waitKey(1)

# 실제 코드 동작 시, 실행할 코드
def run():
    rospy.init_node("stop_line_1_node")     # camera_example이라는 이름으로 노드를 ROS_MASTER에 등록해주는 코드 (이름이 겹치지만 않으면 됨) 
    new_class = StopLine_1()          # 실제 동작을 담당할 Object
    rospy.spin()                         # ROS Node가 종료되지 않고, Callback 함수를 정상적으로 실행해주기 위한 부분 (코드를 유지하면서, 지속적으로 subscriber를 호출해주는 함수)

if __name__ == '__main__':               # 해당 Python 코드를 직접 실행할 때만 동작하도록 하는 부분
    run()                                # 실제 동작하는 코드